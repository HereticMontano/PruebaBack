﻿# Vectors #
En esta parte existe una serie de tests y lo que se debe implementar es el tratamiento de un Set de números que al aplicar un método Filter realiza las acciones que marcan los test, se busca la máxima eficiencia para que el método se ejecute con el mejor rendimiento posible.

Se valorará el buen uso de System.Collections