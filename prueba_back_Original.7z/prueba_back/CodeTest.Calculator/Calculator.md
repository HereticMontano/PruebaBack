﻿# Calculator #
En esta parte tenemos el código de una calculadora con cuatro simples operaciones. Este pedazo de código tiene problemas de extensibilidad y mantenimiento, por eso se va a hacer una refactorización del código antes de que se acometan nuevas funcionalidades.  En un futuro se van a querer implementar operaciones como: ln, exp, arctg, tg... 

Existen unos test muy simples que también deberán adecuarse a la nueva implementación. 

Se valorará el uso de patrones de diseño y el buen uso de la POO.




